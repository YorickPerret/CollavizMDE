package org.collaviz.clientJava3D.pJava3D;



public interface IPJava3D_Ball{

}