package org.collaviz.clientJava3D.pJava3D;

import java.util.Map ;
import javax.vecmath.Quat4d ;
import javax.vecmath.Vector3d ;
import org.collaviz.collaboration.objects.control.IC_SharedObject ;

public class PJava3D_Ball extends PJava3D_SupportedObject implements IPJava3D_Ball {


	public PJava3D_Ball (IC_SharedObject ctr, Vector3d translation, Quat4d rotation, Vector3d scale, PJava3D_ObjectManager presObjManager, String geometry) {
		super (ctr, translation, rotation, scale, geometry, presObjManager);


	}

	@Override
	public void update(String userId, Map<String, Object> params, IC_SharedObject source) {
		super.update (userId, params, source);

	}


}