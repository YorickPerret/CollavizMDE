package org.collaviz.iivc.abstraction;
import org.collaviz.collaboration.objects.control.IC_ObjectManager ;
import org.collaviz.collaboration.objects.utils.ICallbackHandler ;
import org.collaviz.collaboration.objects.utils.Transform ;

public class A_Juncture extends A_DeformableObject implements IA_Juncture {

	//beginBallId and beginBallTransform are used by observedPropertiesChanged()
	protected String beginBallId;
	protected Transform beginBallTransform;
	protected IA_Ball beginBall = null ;
	//endBallId and endBallTransform are used by observedPropertiesChanged()
	protected String endBallId;
	protected Transform endBallTransform;
	protected IA_Ball endBall = null ;
	protected double radius = 0.1;
	protected double length = 0.5;

	public A_Juncture (String objectType, String objectName, IC_ObjectManager objectManager) {
		super (objectType, objectName, objectManager) ;

		beginBallId = null;
		parameters.put("BeginBall",beginBallId);
		endBallId = null;
		parameters.put("EndBall",endBallId);
		parameters.put("Radius",radius);
		parameters.put("Length",length);

		registerModificationCallback ("setNewRadius", new ICallbackHandler () {
			@Override
			public void callback (Object [] args) {
				final double _newRadius = (double)args[0];
				setNewRadius(_newRadius);
			}
		});

	}

	@Override
	public void setNewRadius (double newRadius){
		//you have to add modifications.put("ParameterName", val);
		//for each paramater you want to update
 	}

	@Override
	protected void processUpdate (Map<String, Object> params) {
		super.processUpdate (params) ;

		final String _beginBall = (String)params.get("BeginBall");
		if(_beginBall!=null){
			this.beginBallId=_beginBall;
			parameters.put("BeginBall",this.beginBallId);
		}

		final String _endBall = (String)params.get("EndBall");
		if(_endBall!=null){
			this.endBallId=_endBall;
			parameters.put("EndBall",this.endBallId);
		}

		final double _radius = (double)params.get("Radius");
		if(_radius!=null){
			this.radius=_radius;
			parameters.put("Radius",this.radius);
		}

		final double _length = (double)params.get("Length");
		if(_length!=null){
			this.length=_length;
			parameters.put("Length",this.length);
		}

	}
	@Override
	protected void processModify (Map<String, Object> params) {
		super.processModify (params) ;

		final String _beginBall = (String)params.get("BeginBall");
		if(_beginBall!=null){
			this.beginBallId=_beginBall;
			modifications.put("BeginBall",this.beginBallId);
			beginBall = (IC_SupportedObject)objectManager.getObject(beginBallId);
			beginBall.registerObserver(id);
		}

		final String _endBall = (String)params.get("EndBall");
		if(_endBall!=null){
			this.endBallId=_endBall;
			modifications.put("EndBall",this.endBallId);
			endBall = (IC_SupportedObject)objectManager.getObject(endBallId);
			endBall.registerObserver(id);
		}

		final double _radius = (double)params.get("Radius");
		if(_radius!=null){
			this.radius=_radius;
			modifications.put("Radius",this.radius);
		}

		final double _length = (double)params.get("Length");
		if(_length!=null){
			this.length=_length;
			modifications.put("Length",this.length);
		}

	}
	@Override
	public void observedPropertiesChanged (String obsName, Map<String, Object> chang) {
		super.observedPropertiesChanged(obsName, chang);
		boolean modified = false ;
		if (beginBallId != null && beginBallId.equals(obsName)) {
			final HashMap<String, Double> targetTransformMap = (HashMap<String, Double>) chang.get("Transform");
			if (targetTransformMap != null) {
				modified = true ;
				beginBallTransform = new Transform(targetTransformMap);
			}
			final Boolean isVisibleBeginBall = (Boolean) chang.get("IsVisible");
			if (isVisibleBeginBall != null) {
				boolean myIsVisible = isVisibleBeginBall;
				modifications.put("IsVisible", myIsVisible);
				modified();
			}
		}
		if (endBallId != null && endBallId.equals(obsName)) {
			final HashMap<String, Double> targetTransformMap = (HashMap<String, Double>) chang.get("Transform");
			if (targetTransformMap != null) {
				modified = true ;
				endBallTransform = new Transform(targetTransformMap);
			}
			final Boolean isVisibleEndBall = (Boolean) chang.get("IsVisible");
			if (isVisibleEndBall != null) {
				boolean myIsVisible = isVisibleEndBall;
				modifications.put("IsVisible", myIsVisible);
				modified();
			}
		}
		if (modified) {
			computePosition () ;
			modified () ;
		}
	}

	private void computePosition () {
		if ((beginBallTransform != null) && (endBallTransform != null)){
		}
	}


}