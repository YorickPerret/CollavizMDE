package org.collaviz.iivc.abstraction



public interface IA_Juncture {
	public void setNewRadius (double newRadius);

}