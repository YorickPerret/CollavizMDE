package org.collaviz.iivc.control.client;
import org.collaviz.collaboration.objects.abstraction.IA_SharedObject ;
import org.collaviz.collaboration.objects.control.client.CClient_ObjectManager ;
import org.collaviz.iivc.control.IC_Juncture ;

public class CClient_Juncture extends CClient_DeformableObject implements IC_Juncture {

	public CClient_Juncture(IA_SharedObject abstraction, boolean referentProxyArchi, int accessLevel, CClient_ObjectManager objectManager) {
		super (abstraction, referentProxyArchi, accessLevel, objectManager) ;
	}

	@Override
	public void setNewRadius (double newRadius){
		callModificationMethod ("setNewRadius",newRadius);
	}


}