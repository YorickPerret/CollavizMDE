package org.collaviz.iivc.control

import org.collaviz.iivc.abstraction.IA_Ball

public interface IC_Ball extends IA_Ball{

}