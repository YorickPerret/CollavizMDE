package org.collaviz.iivc.control

import org.collaviz.iivc.abstraction.IA_Juncture

public interface IC_Juncture extends IA_Juncture{

}