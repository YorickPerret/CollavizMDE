package org.collaviz.iivc.control.service;

import org.collaviz.collaboration.objects.abstraction.IA_SharedObject;
import org.collaviz.collaboration.objects.control.service.CService_ObjectManager;
import org.collaviz.iivc.control.IC_Tool;

public class CService_Tool extends CService_SupportedObject implements IC_Tool {

	public CService_Tool(IA_SharedObject abstraction, boolean referentProxyArchi,
						int accessLevel, CService_ObjectManager objectManager) {
		super(abstraction, referentProxyArchi, accessLevel, objectManager);
	}

    @Override
    public void processActionEvent(String actionId, Object[] args) {
        callModificationMethod("processActionEvent", actionId, args);
    }

}
