package org.collaviz.iivc.abstraction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.vecmath.Quat4d;
import javax.vecmath.Vector3d;

import org.collaviz.collaboration.objects.control.IC_ObjectManager;
import org.collaviz.collaboration.objects.control.IC_SharedObject;
import org.collaviz.collaboration.objects.utils.ICallbackHandler;
import org.collaviz.collaboration.objects.utils.Transform;
import org.collaviz.collaboration.objects.utils.Transform3D;
import org.collaviz.iivc.control.IC_OffsetConveyor;
import org.collaviz.iivc.control.IC_SupportedObject;
import org.collaviz.iivc.utils.ToolActionIds;

public class A_Conveyor extends A_InteractiveObject {
	
   protected double rotationFactor = 0.4 ;
   protected double translationFactor = 0.1 ;
   protected double rotationStep = 0.2 ;
   protected double translationStep = 0.05 ;
   protected String cage = null ;
   protected String head = null ;
   protected IC_SupportedObject theCage = null ;
   protected IC_SupportedObject theHead = null ;

    public enum NavigationMode {
        UNKNOWN_NAVIGATION,
        FREE_NAVIGATION,
        TURN_AROUND_NAVIGATION,
        SUPERVISED_NAVIGATION,
        HEAD_NAVIGATION
    }

    
    public static final String UNKNOWN_NAVIGATION_STR = "UnknownNavigationMode";
    public static final String FREE_NAVIGATION_STR = "Normal";
    public static final String TURN_AROUND_NAVIGATION_STR = "TurnAroundNavigationMode";
    public static final String SUPERVISED_NAVIGATION_STR = "SupervisedNavigationMode";
    public static final String HEAD_NAVIGATION_STR = "HeadNavigationMode";

    protected NavigationMode navigationMode;
    protected NavigationMode previousNavigationMode;
    protected Transform previousTransform = new Transform () ;
    protected Vector3d currentPosition = new Vector3d () ;
    protected ArrayList<Vector3d> positionHistory = new ArrayList<Vector3d> () ;

    private boolean turnAroundNavigationInitialized;
    private IC_SharedObject firstOffsetConveyor;
    private Transform firstOffsetConveyorInitialOffset;

    public static String getNavigationName(NavigationMode mode) {
        String name;
        switch (mode) {
            case FREE_NAVIGATION:
                name = FREE_NAVIGATION_STR;
                break;
            case TURN_AROUND_NAVIGATION:
               name = TURN_AROUND_NAVIGATION_STR;
               break;
            case SUPERVISED_NAVIGATION:
                name = SUPERVISED_NAVIGATION_STR;
                break;
            case HEAD_NAVIGATION:
                name = HEAD_NAVIGATION_STR;
                break;
            default:
                name = UNKNOWN_NAVIGATION_STR;
                break;
        }
        return name;
    }

    public static NavigationMode getNavigationMode(String name) {
        NavigationMode mode = NavigationMode.UNKNOWN_NAVIGATION;
        if (name.equals(FREE_NAVIGATION_STR)) {
            mode = NavigationMode.FREE_NAVIGATION;
        } else if (name.equals(TURN_AROUND_NAVIGATION_STR)) {
           mode = NavigationMode.TURN_AROUND_NAVIGATION;
        } else if (name.equals(SUPERVISED_NAVIGATION_STR)) {
            mode = NavigationMode.SUPERVISED_NAVIGATION;
        } else if (name.equals(HEAD_NAVIGATION_STR)) {
            mode = NavigationMode.HEAD_NAVIGATION;
        }
        return mode;
    }

    public A_Conveyor(String objectType, String objectName,	IC_ObjectManager objectManager) {
        super(objectType, objectName, objectManager);

        navigationMode = NavigationMode.FREE_NAVIGATION;
        parameters.put("NavigationMode", FREE_NAVIGATION_STR);

        turnAroundNavigationInitialized = false;
        firstOffsetConveyor = null;
        firstOffsetConveyorInitialOffset = new Transform();
        parameters.put ("TranslationStep", null) ;
        parameters.put ("RotationStep", null) ;
        parameters.put ("TranslationFactor", null) ;
        parameters.put ("RotationFactor", null) ;
        parameters.put ("Cage", null) ;
        parameters.put ("Head", null) ;

        registerModificationCallback("translate", new ICallbackHandler() {
            @Override
            public void callback(Object[] args) {
                final double x = (Double) args[0];
                final double y = (Double) args[1];
                final double z = (Double) args[2];
                translate(x, y, z);
            }
        });
        registerModificationCallback("rotate", new ICallbackHandler() {
            @Override
            public void callback(Object[] args) {
                final double h = (Double) args[0];
                final double p = (Double) args[1];
                final double r = (Double) args[2];
                rotate(h, p, r);
            }
        });
        registerModificationCallback("rotateAroundObject", new ICallbackHandler() {
            @Override
            public void callback(Object[] args) {
                final String target = (String) args[0];
                final double h = (Double) args[1];
                final double p = (Double) args[2];
                final double r = (Double) args[3];
                rotateAroundObject(target, h, p, r);
            }
        });
    }
    
	@Override
	public void processActionEvent(String actionId, Object[] args) {
		super.processActionEvent (actionId, args) ;
		if ((navigationMode == NavigationMode.FREE_NAVIGATION) ||
			(navigationMode == NavigationMode.TURN_AROUND_NAVIGATION) ||
			(navigationMode == NavigationMode.HEAD_NAVIGATION)) {
			if (actionId.equals(ToolActionIds.MOVE_X_UP)) {
				translate(translationStep, 0, 0);
			} else if (actionId.equals(ToolActionIds.MOVE_X_DOWN)) {
				translate(-translationStep, 0, 0);
			} else if (actionId.equals(ToolActionIds.MOVE_Y_UP)) {
				translate(0, translationStep, 0);
			} else if (actionId.equals(ToolActionIds.MOVE_Y_DOWN)) {
				translate(0, -translationStep, 0);
			} else if (actionId.equals(ToolActionIds.MOVE_Z_UP)) {
				translate(0, 0, translationStep);
			} else if (actionId.equals(ToolActionIds.MOVE_Z_DOWN)) {
				translate(0, 0, -translationStep);
			} else if (actionId.equals(ToolActionIds.TURN_X_UP)) {
				rotate(rotationStep, 0, 0);
			} else if (actionId.equals(ToolActionIds.TURN_X_DOWN)) {
				rotate(-rotationStep, 0, 0);
			} else if (actionId.equals(ToolActionIds.TURN_Y_UP)) {
				rotate(0, rotationStep, 0);
			} else if (actionId.equals(ToolActionIds.TURN_Y_DOWN)) {
				rotate(0, -rotationStep, 0);
			} else if (actionId.equals(ToolActionIds.TURN_Z_UP)) {
				rotate(0, 0, rotationStep);
			} else if (actionId.equals(ToolActionIds.TURN_Z_DOWN)) {
				rotate(0, 0, -rotationStep);
			} else if (actionId.equals(ToolActionIds.TRANSLATE_X)) {
				final double val = (Double) args[0];
				translate(val*translationFactor, 0, 0);
			} else if (actionId.equals(ToolActionIds.TRANSLATE_Y)) {
				final double val = (Double) args[0];
				translate(0, val*translationFactor, 0);
			} else if (actionId.equals(ToolActionIds.TRANSLATE_Z)) {
				final double val = (Double) args[0];
				translate(0, 0, -val*translationFactor);
			} else if (actionId.equals(ToolActionIds.ROTATE_X)) {
				final double val = (Double) args[0];
				rotate(-val*rotationFactor, 0, 0);
			} else if (actionId.equals(ToolActionIds.ROTATE_Y)) {
				final double val = (Double) args[0];
				rotate(0, -val*rotationFactor, 0);
			} else if (actionId.equals(ToolActionIds.ROTATE_Z)) {
				final double val = (Double) args[0];
				rotate(0, 0, -val*rotationFactor);
			} else if (actionId.equals(ToolActionIds.PICK)) {
				//System.out.println ("Supervised navigation : PICK") ;
				previousNavigationMode = navigationMode ;
				//positionHistory.clear () ;
				navigationMode = NavigationMode.SUPERVISED_NAVIGATION ;
				if (theCage != null) {
					Map<String, Object> params = new HashMap<String, Object> () ;
					params.put ("IsVisible", true) ;
					theCage.modify (params) ;
				}
			} else if (actionId.equals(ToolActionIds.UNPICK)) {
				//System.out.println ("Supervised navigation : UNPICK") ;
				navigationMode = previousNavigationMode ;
				if (theCage != null) {
					Map<String, Object> params = new HashMap<String, Object> () ;
					params.put ("IsVisible", false) ;
					theCage.modify (params) ;
				}
			} else if (actionId.equals(ToolActionIds.HOME)) {
				if (initialized) {
					Map<String, Object> params = new HashMap<String, Object> () ;
					params.put ("Transform", initialPosition.getMapForm ()) ;
					processModify (params) ;
				}
			}
		}
	}

    @Override
   protected void processUpdate (Map<String, Object> params) {
      super.processUpdate (params) ;

      final String newMode = (String)params.get ("NavigationMode") ;
      if (newMode != null) {
         navigationMode = getNavigationMode (newMode) ;
         parameters.put ("NavigationMode", newMode) ;
      }

      final Double rFactor = (Double)params.get ("RotationFactor") ;
      if (rFactor != null) {
         rotationFactor = rFactor ;
         parameters.put ("RotationFactor", rotationFactor) ;
      }

      final Double tFactor = (Double)params.get ("TranslationFactor") ;
      if (tFactor != null) {
         translationFactor = tFactor ;
         parameters.put ("TranslationFactor", translationFactor) ;
      }
      
      final Double rStep = (Double)params.get ("RotationStep") ;
      if (rStep != null) {
         rotationStep = rStep ;
         parameters.put ("RotationStep", rotationStep) ;
      }

      final Double tStep = (Double)params.get ("TranslationStep") ;
      if (tStep != null) {
         translationStep = tStep ;
         parameters.put ("TranslationStep", translationStep) ;
      }
      
      final String newCage = (String)params.get ("Cage") ;
      if (newCage != null) {
         cage = newCage ;
         theCage = (IC_SupportedObject)objectManager.getObject (cage) ;
         parameters.put ("Cage", cage) ;
      }

      final String newHead = (String)params.get ("Head") ;
      if (newHead != null) {
         head = newHead ;
         theHead = (IC_SupportedObject)objectManager.getObject (head) ;
         parameters.put ("Head", head) ;
      }

   }

   @Override
   protected void processModify (Map<String, Object> params) {
      if (navigationMode == NavigationMode.SUPERVISED_NAVIGATION) {
         previousTransform.set (transform) ;
      }
      super.processModify (params) ;

      final String newMode = (String)params.get ("NavigationMode") ;
      if (newMode != null) {
         changeNavigationMode (newMode) ;
      }

      final Double rFactor = (Double)params.get ("RotationFactor") ;
      if (rFactor != null) {
         rotationFactor = rFactor ;
         modifications.put ("RotationFactor", rotationFactor) ;
      }

      final Double tFactor = (Double)params.get ("TranslationFactor") ;
      if (tFactor != null) {
         translationFactor = tFactor ;
         modifications.put ("TranslationFactor", translationFactor) ;
      }
      
      final Double rStep = (Double)params.get ("RotationStep") ;
      if (rStep != null) {
         rotationStep = rStep ;
         modifications.put ("RotationStep", rotationStep) ;
      }

      final Double tStep = (Double)params.get ("TranslationStep") ;
      if (tStep != null) {
         translationStep = tStep ;
         modifications.put ("TranslationStep", translationStep) ;
      }

      final String newCage = (String)params.get ("Cage") ;
      if (newCage != null) {
         cage = newCage ;
         theCage = (IC_SupportedObject)objectManager.getObject (cage) ;
         modifications.put ("Cage", cage) ;
      }

      final String newHead = (String)params.get ("Head") ;
      if (newHead != null) {
         head = newHead ;
         theHead = (IC_SupportedObject)objectManager.getObject (head) ;
         modifications.put ("Head", head) ;
      }

      if (navigationMode == NavigationMode.SUPERVISED_NAVIGATION) {
         previousTransform.getTranslation (currentPosition) ;
         transform.setTranslation (currentPosition) ;
      }

}

    @Override
    protected void changeSupport(String newSupport) {
        final String oldSupport = (String) parameters.get("Support");
        final IC_SupportedObject oldSupportController = (IC_SupportedObject) objectManager.getObject(oldSupport);
        final IC_SupportedObject newSupportController = (IC_SupportedObject) objectManager.getObject(newSupport);
        
        if (!newSupport.equals(oldSupport)) {
           if (newSupport.equals(NOSUPPORT)) {
              if(!oldSupport.equals(NOSUPPORT)){
                 if (oldSupportController != null) {
                    oldSupportController.unregisterSupportedObject(id);
                 } else {
                    System.out.println ("WARNING : the old support should not been null (1)") ;
                 }
              }
              supportObject = null;
              modifications.put("Support", NOSUPPORT);
              offset.reset();
              modifications.put("Offset", offset.getMapForm());
           } else if (oldSupport.equals(NOSUPPORT)) {
              supportObject = objectManager.getObject(newSupport);
              modifications.put("Support", newSupport);
              updateOffsetTransform();
              if (navigationMode == NavigationMode.TURN_AROUND_NAVIGATION) {
                 initiateTurnAroundNavigation();
              }
              if (newSupportController != null) {
                 newSupportController.registerSupportedObject(id);
              } else {
                 System.out.println ("WARNING : the new support should not been null (2)") ;
              }
           } else {
              if (oldSupportController != null) {
                 oldSupportController.unregisterSupportedObject(id);
              } else {
                 System.out.println ("WARNING : the old support should not been null (2)") ;
              }
              supportObject = objectManager.getObject(newSupport);
              modifications.put("Support", newSupport);
              updateOffsetTransform();
              if (navigationMode == NavigationMode.TURN_AROUND_NAVIGATION) {
                 initiateTurnAroundNavigation();
              }
              if (newSupportController != null) {
                 newSupportController.registerSupportedObject(id);
              } else {
                 System.out.println ("WARNING : the new support should not been null (2)") ;
              }
           }
        }
    }

    protected void changeNavigationMode(String newNavigationMode) {
    	System.out.println("changeNavigationMode : " + newNavigationMode);
        final NavigationMode mode = getNavigationMode(newNavigationMode);
        if (mode != NavigationMode.UNKNOWN_NAVIGATION) {
            switch (mode) {
                case FREE_NAVIGATION:
                    isPickable = true;
                    changeSupport(NOSUPPORT);
                    getbackToNormalNavigationMode();
                    break;
                case TURN_AROUND_NAVIGATION:
                    isPickable = false;
                    turnAroundNavigationInitialized = false;
                    initiateTurnAroundNavigation();
                    break;
                case HEAD_NAVIGATION:
                	System.out.println("changeNavigationMode : HEAD_NAVIGATION");
                    break;
                default:
                    break;
            }
            navigationMode = mode;
            modifications.put("NavigationMode", newNavigationMode);
            modifications.put("IsPickable", isPickable);
        }
    }

    @SuppressWarnings("unchecked")
	public synchronized void translate(double x, double y, double z) {
        switch (navigationMode) {
            case FREE_NAVIGATION:
                objectFrameTranslate(x, y, z);
                break;
            case TURN_AROUND_NAVIGATION:
               if (turnAroundNavigationInitialized) {
                   supportFrameTranslate(x, y, z);
               }
               break;
            case HEAD_NAVIGATION:
            	if (theHead != null) {
            		final HashMap<String, Double> transformMap = (HashMap<String, Double>)theHead.getParameter ("Transform") ;
            		if (transformMap != null) {
            			Transform headTransform = new Transform (transformMap) ;
            			Quat4d headRotation = new Quat4d () ;
            			Vector3d headTranslation = new Vector3d () ;
            			Vector3d headScale = new Vector3d () ;
            			headTransform.getRotation (headRotation) ;
            			headTransform.getTranslation (headTranslation) ;
            			headTransform.getScale (headScale) ;
            			
//            			double  [] eulerAngles = new double [3] ;
//            			Transform.quatToEuler(headRotation, eulerAngles) ;
//            			Quat4d flatHeadRotation = new Quat4d () ; 
//            			flatHeadRotation.set(new AxisAngle4d(0, 1, 0, eulerAngles [1])) ;
            			Transform3D headTransform3D = new Transform3D (headRotation, headTranslation, headScale.x) ;
            			Transform3D headTransform3Dinv = new Transform3D () ;
            			headTransform3Dinv.invert (headTransform3D) ;

            			Quat4d rotation = new Quat4d () ;
            			Vector3d translation = new Vector3d () ;
            			Vector3d scale = new Vector3d () ;
            			transform.getRotation (rotation) ;
            			transform.getTranslation (translation) ;
            			double initialY = translation.y ;
            			transform.getScale (scale) ;
            			Transform3D oldTransform3D = new Transform3D (rotation, translation, scale.x) ;

            			Quat4d deltaRotation = new Quat4d () ;
            			Vector3d deltaTranslation = new Vector3d (x, y, z) ;
            			Transform3D deltaTransform3D = new Transform3D (deltaRotation, deltaTranslation, 1) ;
            			Transform3D newTransform3D = new Transform3D () ;
            			newTransform3D.mul (headTransform3D, deltaTransform3D) ;
            			newTransform3D.mul (newTransform3D, headTransform3Dinv) ;
            			newTransform3D.mul (newTransform3D, oldTransform3D) ;
            			Vector3d newTranslation = new Vector3d () ;
            			newTransform3D.get(newTranslation) ;
            			newTranslation.y = initialY ;
            			newTransform3D.setTranslation (newTranslation) ;
            			transform.set(newTransform3D) ;
                        HashMap<String, Double> temporaryTransformMap = new HashMap<String, Double> () ;
                        transform.getMapForm (temporaryTransformMap) ;
                        modifications.put ("Transform", temporaryTransformMap) ;
            		}
            	} else {
            		theHead = (IC_SupportedObject)objectManager.getObject (head) ;
             	}
            	break;
            default:
            	break;
        }
    }

    public synchronized void rotate(double h, double p, double r) {
        switch (navigationMode) {
            case FREE_NAVIGATION:
                objectFrameRotate(h, p, r);
                break;
            case TURN_AROUND_NAVIGATION:
                if (turnAroundNavigationInitialized) {
                    objectFrameRotate(h, p, r);
                }
                break;
            case HEAD_NAVIGATION:
            	objectFrameRotate(h, p, r);
                break;
            default:
                break;
        }
    }

    @SuppressWarnings("unchecked")
    protected void initiateTurnAroundNavigation() {
        // Get the first IC_OffsetConveyor and this initial offset
        for(String observerName : observerNames){
            IC_SharedObject observer = objectManager.getObject(observerName);
            if (observer instanceof IC_OffsetConveyor) {
                firstOffsetConveyor = observer;
                firstOffsetConveyorInitialOffset = new Transform((Map<String, Double>) observer.getParameter("Offset"));
                break;
            }
        }
        // Put the conveyor on the observed object
        offset.reset();
        modifications.put("Offset", offset.getMapForm());
        updateAbsoluteTransform();

        turnAroundNavigationInitialized = true;
    }

    protected void getbackToNormalNavigationMode() {
        if (firstOffsetConveyor != null && observerNames.contains(firstOffsetConveyor.getId())) {
            // Get the first offsetConveyor current transform
            @SuppressWarnings("unchecked")
            final Transform offsetConveyorTransform = new Transform((Map<String, Double>) firstOffsetConveyor.getParameter("Transform"));

            // Compute the new transform
            firstOffsetConveyorInitialOffset.inverse();
            transform.product(offsetConveyorTransform, firstOffsetConveyorInitialOffset);
            modifications.put("Transform", transform.getMapForm());
            if (supportObject != null) {
                updateOffsetTransform();
            }

            // Reset the firstStage and its offset
            firstOffsetConveyor = null;
            firstOffsetConveyorInitialOffset.reset();
        }
    }

    public void rotateAroundObject(String target, double h, double p, double r) {
        if (navigationMode != NavigationMode.TURN_AROUND_NAVIGATION) {
            return;
        }

        if (supportObject == null || !target.equals(supportObject.getId())) {
            changeSupport(target);
        }

        if (turnAroundNavigationInitialized) {
            objectFrameRotate(h, p, r);
        }
    }
        
    @Override
    public void observedPropertiesChanged(String obsName, Map<String, Object> chang) {
       if (navigationMode == NavigationMode.SUPERVISED_NAVIGATION) {
          boolean supervised = false ;
          //System.out.println ("Supervised navigation : observedPropertiesChanged") ;
          if (supportObject != null && supportObject.getId().equals(obsName)) {
             @SuppressWarnings("unchecked")
             final HashMap<String, Double> parentTransformMap = (HashMap<String, Double>) chang.get("Transform");
             if (parentTransformMap != null) {
                Vector3d previousPosition = new Vector3d () ;
                Vector3d currentDirection = new Vector3d () ;
                Quat4d currentOrientation = new Quat4d () ;
                Vector3d initialDirection = new Vector3d (0, 0, -1) ;
                transform.getTranslation (previousPosition) ;
                if (positionHistory.size () > 200) {
                   positionHistory.remove (0) ;
                }
                positionHistory.add (new Vector3d (previousPosition)) ;
                Transform temporaryTransform = new Transform () ;
                HashMap<String, Double> temporaryOffsetTransformMap = new HashMap<String, Double> () ;
                HashMap<String, Double> temporaryAbsoluteTransformMap = new HashMap<String, Double> () ;
                temporaryTransform.set (parentTransformMap) ;
                transform.product (temporaryTransform, offset) ;
                transform.getTranslation (currentPosition) ;
                Vector3d average = new Vector3d () ;
                for (Vector3d v : positionHistory) {
                   average.add (v) ;
                }
                average.x = average.x / positionHistory.size () ;
                average.z = average.z / positionHistory.size () ;
                average.y = average.y / positionHistory.size () ;
                currentDirection.sub (currentPosition, average) ;
                currentDirection.y = 0 ; // to avoid elevation and roll changes
                if (currentDirection.length () > 0.05) {
                   Transform.getRotationBetween2Vectors (initialDirection, currentDirection, currentOrientation) ;
                   //changeWorldFrameRotation (currentOrientation.x, currentOrientation.y, currentOrientation.z, currentOrientation.w) ;
                   transform.setRotation (currentOrientation) ;
                   //transform.setTranslation (currentPosition) ;
                }
//                Vector3d scale = new Vector3d () ;
//                transform.getScale (scale) ;
//                System.out.println ("A_Conveyor : scale = " + scale) ;
                transform.getMapForm (temporaryAbsoluteTransformMap) ;
                modifications.put ("Transform", temporaryAbsoluteTransformMap) ;
                temporaryTransform.set (parentTransformMap) ;
                temporaryTransform.inverse () ;
                offset.product (temporaryTransform, transform) ;
                offset.getMapForm (temporaryOffsetTransformMap) ;
                modifications.put ("Offset", temporaryOffsetTransformMap) ;
                supervised = true ;
                //processModify (modifications) ;
                modified () ; 
             }
          }
          if (! supervised) {
             super.observedPropertiesChanged (obsName, chang) ;
          }
       } else {
          super.observedPropertiesChanged (obsName, chang) ;
       }
    }

}
