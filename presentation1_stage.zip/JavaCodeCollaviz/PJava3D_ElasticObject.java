package org.collaviz.clientJava3D.pJava3D;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Geometry;
import javax.media.j3d.Group;
import javax.media.j3d.Material;
import javax.media.j3d.Node;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.RenderingAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Switch;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Point3d ;
import javax.vecmath.Quat4d;
import javax.vecmath.Vector3d;

import org.collaviz.clientJava3D.StartGraphicClient;
import org.collaviz.clientJava3D.core.ISceneGraphObject;
import org.collaviz.collaboration.objects.control.IC_ObjectManager;
import org.collaviz.collaboration.objects.control.IC_SharedObject;
import org.collaviz.collaboration.objects.presentation.IP_SharedObject;
import org.collaviz.collaboration.objects.utils.Color;
import org.collaviz.collaboration.objects.utils.Transform;
import org.jdesktop.j3d.loaders.vrml97.VrmlLoader;

import com.interactivemesh.j3d.interchange.ext3d.XImportOptions;
import com.interactivemesh.j3d.interchange.ext3d.XModelReader;
import com.sun.j3d.loaders.Scene;
import com.sun.j3d.utils.geometry.Box;
import com.sun.j3d.utils.geometry.Cylinder;
import com.sun.j3d.utils.geometry.Sphere;

/**
 * Base class to represent a virtual 3D object that can be selected and modified.
 * The default geometry is a ColorCube.
 *
 * @author Cédric Fleury &lt;cedric.fleury@irisa.fr&gt;
 * @author Thierry Duval &lt;thierry.duval@irisa.fr&gt; (first version)
 */
public class PJava3D_ElasticObject extends PJava3D_DeformableObject {

   protected float length = 1.0f ;
   protected float radius = 0.1f ;

    public PJava3D_ElasticObject (IC_SharedObject ctr, Vector3d translation, Quat4d rotation, Vector3d scale, String geometry, float radius, float length, PJava3D_ObjectManager presObjManager) {
        super (ctr, translation, rotation, scale, geometry, presObjManager);
        this.length = length ;
        this.radius = radius ;
    }   
    
    @Override
    public void update(String userId, Map<String, Object> params, IC_SharedObject source) {
    	super.update (userId, params, source) ;
    	boolean rlToUpdate = false ;
       Double theLength = (Double) params.get("Length");
       if (theLength != null) {
          length = theLength.floatValue () ;
          rlToUpdate = true ;
       }
       
       Double theRadius = (Double) params.get("Radius");
       if (theRadius != null) {
          radius = theRadius.floatValue () ;
          rlToUpdate = true ;
       }

       if (rlToUpdate) {
          updateLengthRadius (length, radius);
       }
       

    }

    private void updateLengthRadius (float theLength, float theRadius) {
       length = theLength ;
       radius = theRadius ;
       Point3d [] coordinates = new Point3d [8] ;
       coordinates [0] = new Point3d (-radius / 2, -radius / 2, -length / 2) ;
       coordinates [1] = new Point3d (-radius / 2, -radius / 2, length / 2) ;
       coordinates [2] = new Point3d (-radius / 2, radius / 2, -length / 2) ;
       coordinates [3] = new Point3d (-radius / 2, radius / 2, length / 2) ;
       coordinates [4] = new Point3d (radius / 2, -radius / 2, -length / 2) ;
       coordinates [5] = new Point3d (radius / 2, -radius / 2, length / 2) ;
       coordinates [6] = new Point3d (radius / 2, radius / 2, -length / 2) ;
       coordinates [7] = new Point3d (radius / 2, radius / 2, length / 2) ;
       if (deformableShape != null) {
          for (int i = 0 ; i < coordinates.length ; i++) {
             deformableShape.setCoordinate (i, coordinates [i]) ;
          }
       }
    }

}

