package org.collaviz.iivc.control.client;

import java.util.HashMap;

import org.collaviz.collaboration.objects.abstraction.IA_SharedObject;
import org.collaviz.collaboration.objects.control.client.CClient_ObjectManager;
import org.collaviz.iivc.control.IC_Conveyor;

public class CClient_Conveyor extends CClient_Tool implements IC_Conveyor {

    public CClient_Conveyor(IA_SharedObject abs, boolean refProx,int accessLevel, CClient_ObjectManager objectManager) {
        super(abs, refProx, accessLevel, objectManager);
    }

    public void changeNavigationMode(String newNavigationMode) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("NavigationMode", newNavigationMode);
        modify(map);
    }

    @Override
    public void translate(double x, double y, double z) {
        callModificationMethod("translate", x, y, z);
    }

    @Override
    public void rotate(double h, double p, double r) {
        callModificationMethod("rotate", h, p, r);
    }

    @Override
    public void rotateAroundObject(String target, double h, double p, double r){
        callModificationMethod("rotateAroundObject", target, h, p, r);
    }

}
