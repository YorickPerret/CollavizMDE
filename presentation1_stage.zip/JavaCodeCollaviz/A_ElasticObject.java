package org.collaviz.iivc.abstraction;

import java.util.HashMap ;
import java.util.Map ;

import javax.vecmath.Point3d ;
import javax.vecmath.Quat4d ;
import javax.vecmath.Vector3d ;

import org.collaviz.collaboration.objects.control.IC_ObjectManager ;
import org.collaviz.collaboration.objects.utils.Transform ;
import org.collaviz.iivc.control.IC_SupportedObject ;
import org.collaviz.iivc.control.IC_WorldObject ;

public class A_ElasticObject extends A_DeformableObject {

	/**
	 * An object whose two extremities are attached to 2 different objects and its length change according to the distance
	 * between these 2 objects
	 */

   protected String end1Id;
   protected String end2Id;
   protected IC_WorldObject end1Object;
   protected IC_WorldObject end2Object;
   protected Transform end1Transform ;
   protected Transform end2Transform ;
   protected double length = 1 ;
   protected double radius = 0.1 ;

	public A_ElasticObject (String objectType, String objectName, IC_ObjectManager objectManager) {
		super (objectType, objectName, objectManager) ;

      end1Id = null;
      end2Id = null;
      parameters.put("End1", end1Id);
      parameters.put("End2", end2Id);
      parameters.put("Radius", radius);
      parameters.put("Length", length);

	}

	@Override
	protected void processUpdate(Map<String, Object> params) {
		super.processUpdate(params);

		final String attObj1Id = (String) params.get ("End1");
		if (attObj1Id != null) {
			end1Id = attObj1Id;
			parameters.put("End1", end1Id);
		}

      final String attObj2Id = (String) params.get("End2");
      if (attObj2Id != null) {
         end2Id = attObj2Id;
         parameters.put("End2", end2Id);
      }

      final Double theRadius = (Double) params.get("Radius");
      if (theRadius != null) {
         radius = theRadius;
         parameters.put("Radius", radius);
      }

      final Double theLength = (Double) params.get("Length");
      if (theLength != null) {
         length = theLength;
         parameters.put("Length", length);
      }

	}

	@Override
	protected void processModify (Map<String, Object> params) {
	   super.processModify (params);

	   final String attObj1Id = (String) params.get("End1");
	   if (attObj1Id != null) {
	      end1Id = attObj1Id;
	      modifications.put("End1", end1Id);
	      end1Object = (IC_SupportedObject)objectManager.getObject(end1Id);
	      end1Object.registerObserver(id);
	   }

      final String attObj2Id = (String) params.get("End2");
      if (attObj2Id != null) {
         end2Id = attObj2Id;
         modifications.put("End2", end2Id);
         end2Object = (IC_SupportedObject)objectManager.getObject(end2Id);
         end2Object.registerObserver(id);
      }

      final Double theRadius = (Double) params.get("Radius");
      if (theRadius != null) {
         radius = theRadius;
         modifications.put("Radius", radius);
      }

      final Double theLength = (Double) params.get("Length");
      if (theLength != null) {
         length = theLength;
         modifications.put("Length", length);
      }

	}
	
   @SuppressWarnings ("unchecked")
   @Override
   public void observedPropertiesChanged (String obsName, Map<String, Object> chang) {
      super.observedPropertiesChanged(obsName, chang);
      //System.out.println ("observedPropertiesChanged 1 : " + obsName) ;
      boolean modified = false ;
      if (end1Id != null && end1Id.equals(obsName)) {
         final HashMap<String, Double> targetTransformMap = (HashMap<String, Double>) chang.get("Transform");
         if (targetTransformMap != null) {
            modified = true ;
            end1Transform = new Transform(targetTransformMap);
         }
         final Boolean isVisibleEnd1= (Boolean) chang.get("IsVisible");
         if (isVisibleEnd1 != null) {
        	 boolean myIsVisible = isVisibleEnd1;
        	 modifications.put("IsVisible", myIsVisible);
        	 modified () ;
         }
      }
      if (end2Id != null && end2Id.equals(obsName)) {
         final HashMap<String, Double> targetTransformMap = (HashMap<String, Double>) chang.get("Transform");
         if (targetTransformMap != null) {
            modified = true ;
            end2Transform = new Transform(targetTransformMap);
         }
         final Boolean isVisibleEnd2= (Boolean) chang.get("IsVisible");
         if (isVisibleEnd2 != null) {
        	 boolean myIsVisible = isVisibleEnd2;
        	 modifications.put("IsVisible", myIsVisible);
        	 modified ();
         }
      }
      if (modified) {
         computePosition () ;
         modified () ;         
      }
   }

   private void computePosition () {
      if ((end1Transform != null) && (end2Transform != null)) {
         Vector3d translation1 = new Vector3d () ; 
         Vector3d translation2 = new Vector3d () ; 
         end1Transform.getTranslation (translation1) ;
         end2Transform.getTranslation (translation2) ;
         transform.setTranslation ((translation1.x + translation2.x) / 2,
               (translation1.y + translation2.y) / 2,
               (translation1.z + translation2.z) / 2) ;
         Quat4d orientation = new Quat4d () ;
         Point3d p1 = new Point3d (translation1.x, translation1.y, translation1.z) ;
         Point3d p2 = new Point3d (translation2.x, translation2.y, translation2.z) ;
         length = p1.distance (p2) ;
         Point3d p1p2 = new Point3d (p2) ;
         p1p2.sub (p1) ;         
         Vector3d v = new Vector3d (p1p2) ;
         Transform.getRotationBetween2Vectors (new Vector3d (0, 0, -1), v, orientation) ;
         transform.setRotation (orientation) ;
         //transform.setScale (new Vector3d (1, p1.distance (p2), 1)) ;
         Map<String, Object> params = new HashMap <String, Object> () ;
         params.put ("Transform", transform.getMapForm ()) ;
         params.put ("Length", length) ;
         processModify (params) ;
      }
   }

}
