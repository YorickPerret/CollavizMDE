package org.collaviz.iivc.control.service;

import org.collaviz.collaboration.objects.abstraction.IA_SharedObject;
import org.collaviz.collaboration.objects.control.service.CService_ObjectManager;
import org.collaviz.iivc.control.IC_Conveyor;

public class CService_Conveyor extends CService_Tool implements IC_Conveyor {

    public CService_Conveyor(IA_SharedObject abs, boolean refProx,int accessLevel, CService_ObjectManager objectManager) {
        super(abs, refProx, accessLevel, objectManager);
    }

    @Override
    public void translate(double x, double y, double z) {
        callModificationMethod("translate", x, y, z);
    }

    @Override
    public void rotate(double h, double p, double r) {
    	callModificationMethod("rotate", h, p, r);
    }
    
    @Override
    public void rotateAroundObject(String target, double h, double p, double r){
    	callModificationMethod("rotateAroundObject", target, h, p, r);
    }
    
}
