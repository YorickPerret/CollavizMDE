package org.collaviz.iivc.control.client;

import org.collaviz.collaboration.objects.abstraction.IA_SharedObject;
import org.collaviz.collaboration.objects.control.client.CClient_ObjectManager;
import org.collaviz.iivc.control.IC_Tool;

public class CClient_Tool extends CClient_SupportedObject implements IC_Tool {

	public CClient_Tool(IA_SharedObject abstraction, boolean referentProxyArchi,
						int accessLevel, CClient_ObjectManager objectManager) {
		super(abstraction, referentProxyArchi, accessLevel, objectManager);
	}

    @Override
    public void processActionEvent(String actionId, Object[] args) {
        callModificationMethod("processActionEvent", actionId, args);
    }

}
